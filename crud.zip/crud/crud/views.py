from django.shortcuts import render
from django.http import JsonResponse
import json
import requests
from books.models import *

def output_data(status_code, status, message=None):
    result = {
               "status_code": status_code,
               "status": status,
               "data": []
             }
    if message:
        result['message'] = message
    return result

def get_external_book(request, name):
    name =  name[6:]
    print("BOOK: ", name)
    url = "https://www.anapioficeandfire.com/api/books"
    
    book_name = name
    url = "https://www.anapioficeandfire.com/api/books?name={}".format(book_name)
    response = requests.get(url)
    
    if response.status_code == 200:
        data = json.loads(response.content.decode('utf-8'))
        if data:
            result = output_data(response.status_code, "success")
            result['data'].append({
                         "name": data[0].get("name"),
                         "isbn": data[0].get("isbn"),
                         "authors": data[0].get("authors"),
                         "numberOfPages": data[0].get("numberOfPages"),
                         "publisher": data[0].get("publisher"),
                         "country": data[0].get("country"),
                         "release_date": data[0].get("released")
                        })
            return JsonResponse(result)
        else:
            return JsonResponse(output_data(response.status_code, "success")) 


def home(request):
    url = "https://www.anapioficeandfire.com/api/books"
    
    book_name = "A Clash of Kings"
    url = "https://www.anapioficeandfire.com/api/books?name={}".format(book_name)
    response = requests.get(url)
    
    if response.status_code == 200:
        data = json.loads(response.content.decode('utf-8'))
        if data:
            result = output_data(response.status_code, "success")
            result['data'].append({
                         "name": data[0].get("name"),
                         "isbn": data[0].get("isbn"),
                         "authors": data[0].get("authors"),
                         "numberOfPages": data[0].get("numberOfPages"),
                         "publisher": data[0].get("publisher"),
                         "country": data[0].get("country"),
                         "release_date": data[0].get("released")
                        })
            return JsonResponse(result)
        else:
            return JsonResponse(output_data(response.status_code, "success")) 


def crud(request):
    book_name = "A Clash of Kings"
    url = "https://www.anapioficeandfire.com/api/books?name={}".format(book_name)
    
    if request.method == "POST":
        data = request.body.decode('utf-8') 
        received_json_data = json.loads(data)
        print(received_json_data['name'])
        name = received_json_data['name']
        isbn = received_json_data['isbn']
        authors = received_json_data['authors']
        number_of_pages = received_json_data['number_of_pages']
        publisher = received_json_data['publisher']
        country = received_json_data['country']
        release_date = received_json_data['release_date']
        
        book = Book.objects.create(name=name, isbn=isbn, number_of_pages=number_of_pages, publisher=publisher,\
        country=country, release_date=release_date)
        for author in authors:
            cur_author = Author.objects.get_or_create(name=author)
            # print("CA", cur_author[0])
            ca = Author.objects.get(name = cur_author[0])
            book.authors.add(ca)
        book.save()
        
        result = output_data(201, "success")
        result['data'].append({
                        "name": name,
                        "isbn": isbn,
                        "authors": authors,
                        "number_of_pages": number_of_pages,
                        "publisher": publisher,
                        "country": country,
                        "release_date": release_date
                    })
        return JsonResponse(result)

    else:
        all_books = Book.objects.all()

        if len(all_books)>0:
            result = output_data(201, "success")
            
            for book in all_books:
                cur_book_data = []
                cur_book_data.append({
                            "id": book.id,
                            "name": book.name,
                            "isbn": book.isbn,
                            "authors": book.authors,
                            "number_of_pages": book.number_of_pages,
                            "publisher": book.publisher,
                            "country": book.country,
                            "release_date": book.release_date
                        })
                result['data'].append(cur_book_data)
            return JsonResponse(output_data(201, "success")) 
        else:
            return JsonResponse(output_data(response.status_code, "success")) 
