from django.contrib import admin
from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('api/external-books/<str:name>', views.get_external_book, name='get_external_book'),
    path('api/v1/books', csrf_exempt(views.crud) , name='crud'),
]
