from django.db import models

class Author(models.Model):
    name = models.CharField(max_length=1000, blank=True, null=True)
    def __str__(self):
        return self.name

class Book(models.Model) :
    name = models.CharField(max_length=1000, blank=True, null=True)
    isbn = models.CharField(max_length=100, blank=True, null=True)
    number_of_pages = models.IntegerField(blank=True, null=True)
    publisher = models.CharField(max_length=100, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    release_date = models.DateTimeField()
    authors = models.ManyToManyField('Author', default="tqr")
    def __str__(self):
        return self.name