Steps to Run:

1. Clone the project.

2. Create virtual enviornment and activate it.

3. Install requirements.

4. Run
	a. python manage.py makemigrations
	b. python manage.py migrate
	c. python manage.py runserver

5. Then test by sending different http requests.